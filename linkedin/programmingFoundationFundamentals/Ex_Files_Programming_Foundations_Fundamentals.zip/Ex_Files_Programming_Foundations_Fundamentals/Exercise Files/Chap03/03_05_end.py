print("Hi!")
name = input("What's your name? ")

print("It's nice to meet you,", name)
answer = input("Are you enjoying the course? ")

if answer == "Yes":
    print("That's good to hear!")
else:
    print("Oh no! That makes me sad!")