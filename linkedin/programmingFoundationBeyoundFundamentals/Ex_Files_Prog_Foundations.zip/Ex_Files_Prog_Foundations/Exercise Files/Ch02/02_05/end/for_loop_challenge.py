fruits = [
    'apples',
    'bananas',
    'dragon fruit',
    'mangos',
    'nectarines',
    'pears',
]
print('Our fruit selection:')
for fruit in fruits:
    print(fruit)