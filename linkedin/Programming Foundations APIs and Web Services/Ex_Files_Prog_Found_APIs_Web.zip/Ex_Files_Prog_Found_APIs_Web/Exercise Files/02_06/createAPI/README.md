The application uses an H2 In Memory database, with the console being found at http://localhost:8080/console
The jdbc url should be: jdbc:h2:mem:bugtracker
The user name is "sa" and there is no password