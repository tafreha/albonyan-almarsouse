for value in range(10):
    print(value)
print('All done!')