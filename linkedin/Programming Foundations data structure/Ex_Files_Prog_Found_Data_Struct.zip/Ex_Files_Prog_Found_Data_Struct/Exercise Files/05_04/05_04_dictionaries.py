# Key: State
# Value: Capital

statesToCapitals = {}

statesToCapitals["Texas"] = "Austin"
statesToCapitals["New York"] = "Albany"

print(statesToCapitals["New York"])
