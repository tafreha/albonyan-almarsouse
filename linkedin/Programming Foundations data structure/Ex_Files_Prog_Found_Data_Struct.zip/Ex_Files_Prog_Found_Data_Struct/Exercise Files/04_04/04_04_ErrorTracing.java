import java.util.Stack;
public class MyClass {
	public static void main(String args[]) {
		Stack myStack = new Stack();
		myStack.push("hi");
		myStack.pop();
	}
}
