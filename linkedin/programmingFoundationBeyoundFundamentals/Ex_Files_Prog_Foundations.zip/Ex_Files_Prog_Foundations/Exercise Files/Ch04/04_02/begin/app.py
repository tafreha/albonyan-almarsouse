first_name = 'malala'
last_name = 'yousafzai'
note = 'award: Nobel Peace Prize'
