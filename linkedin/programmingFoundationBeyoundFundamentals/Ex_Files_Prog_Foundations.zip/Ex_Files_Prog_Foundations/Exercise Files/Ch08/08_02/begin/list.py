flips = [
    'heads',
    'tails',
    'tails',
    'heads',
    'tails',
]

