miles = input('Enter a distance in miles: ')
# kilometers_value = miles_value * 1.609344
