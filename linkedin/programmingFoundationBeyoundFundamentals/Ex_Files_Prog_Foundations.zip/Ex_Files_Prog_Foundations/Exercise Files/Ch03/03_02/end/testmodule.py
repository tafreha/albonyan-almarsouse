def mult(x, y):
    print(f'{x} * {y} = {x * y}')