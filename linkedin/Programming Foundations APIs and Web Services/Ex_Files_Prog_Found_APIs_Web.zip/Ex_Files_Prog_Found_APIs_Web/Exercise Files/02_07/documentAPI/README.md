The application uses an H2 In Memory database

1.)TicketManagement
Runs on port: 8080
H2 Console: http://localhost:8080/console
The jdbc url should be: jdbc:h2:mem:testdb
The user name is "sa" and there is no password

2.) ApplicationCatalog
Runs on port: 8081
H2 Console: http://localhost:8081/console/
The jdbc url should be: jdbc:h2:mem:testdb
The user name is "sa" and there is no password

3.) UseManagement
Runs on port: 8082
H2 Console: http://localhost:8082/console/
The jdbc url should be: jdbc:h2:mem:testdb
The user name is "sa" and there is no password

