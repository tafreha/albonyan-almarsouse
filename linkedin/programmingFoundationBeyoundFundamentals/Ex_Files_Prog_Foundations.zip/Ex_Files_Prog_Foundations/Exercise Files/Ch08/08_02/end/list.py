flips = [
    'heads',
    'tails',
    'tails',
    'heads',
    'tails',
]

print(flips.count('heads'))
print(flips.pop())
