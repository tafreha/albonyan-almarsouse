spices = [
    'salt',
    'pepper',
    'cumin',
    'turmeric',
]
