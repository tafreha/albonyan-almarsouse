print("~~~ The Shimmy ~~~")

print("Take one step to the right and stomp.")
print("Take one step to the left and stomp.")
print("Shake those hips!") 
